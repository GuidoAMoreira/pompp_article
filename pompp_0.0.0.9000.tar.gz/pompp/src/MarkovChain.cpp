#include "include/MarkovChain.hpp"

// This is needed only to fix a virtual table problem with clang++
// void MarkovChain::doNothing() {}
