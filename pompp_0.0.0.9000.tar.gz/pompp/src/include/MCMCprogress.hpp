#ifndef __MCMC_progress_bar_HPP__
#define __MCMC_progress_bar_HPP__

// A modified progress bar. Inspired heavily by the RcppProgress package.

class MCMCprogress {
public:
  void increment(unsigned int);

  MCMCprogress() {}

  // TODO: EVERYTHING!!
};

#endif
